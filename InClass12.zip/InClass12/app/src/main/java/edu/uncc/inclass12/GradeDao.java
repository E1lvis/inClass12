package edu.uncc.inclass12;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface GradeDao {
    @Query("SELECT * from grades")
    List<Grade> getAll();

    @Query("SELECT * from grades WHERE id = :id limit 1")
    Grade findById(long id);

    @Update
    void update(Grade grade);


    @Insert
    void insert(Grade  grade);

    @Delete
    void delete(Grade grade);
}
