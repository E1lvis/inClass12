//InClass12
//InClass12
//Elvis Velasquez, Eduardo Gomez

package edu.uncc.inclass12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import androidx.room.Room;

import java.util.List;

public class MainActivity extends AppCompatActivity implements GradesFragment.gradesListener, AddCourseFragment.addGradeListener, gradeRecyclerViewAdapter.adapterListener{
    AppDatabase db;
    List<Grade> grades;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = Room.databaseBuilder(this, AppDatabase.class, "grade.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //Grade grade = db.gradeDao().findById(3);
        //db.gradeDao().delete(grade);
        Log.d("TAG", "onCreate: " + db.gradeDao().getAll());
        grades = db.gradeDao().getAll();

        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, GradesFragment.newInstance(grades))
                .commit();
    }


    @Override
    public void goToAdd() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new AddCourseFragment())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void deleteGrade(Grade grade) {
        Log.d("", "deleteGrade: RANANANA");
        Grade g = grade;
        db.gradeDao().delete(grade);
        grades = db.gradeDao().getAll();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, GradesFragment.newInstance(grades))
                .commit();

    }

    @Override
    public void courseAdded(Grade grade) {
        db.gradeDao().insert(grade);
        grades = db.gradeDao().getAll();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, GradesFragment.newInstance(grades))
                .commit();
    }

    @Override
    public void cancel() {
        getSupportFragmentManager().popBackStack();
    }
}