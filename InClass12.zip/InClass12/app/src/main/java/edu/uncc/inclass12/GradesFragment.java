package edu.uncc.inclass12;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import java.io.Serializable;
import java.util.List;

import edu.uncc.inclass12.databinding.FragmentGradesBinding;

public class GradesFragment extends Fragment implements gradeRecyclerViewAdapter.adapterListener {
    List<Grade> mlist;
    public GradesFragment() {
        // Required empty public constructor
    }

    public static GradesFragment newInstance(List<Grade> mlist) {
        Bundle args = new Bundle();
        args.putSerializable("grades", (Serializable) mlist);
        GradesFragment fragment = new GradesFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments() != null){
            mlist = (List<Grade>) getArguments().getSerializable("grades");
        }

    }

    FragmentGradesBinding binding;

    RecyclerView recyclerView;
    gradeRecyclerViewAdapter adapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGradesBinding.inflate(inflater, container, false);

        setHasOptionsMenu(true);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.recycler.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new gradeRecyclerViewAdapter(mlist, this );
        binding.recycler.setAdapter(adapter);
        binding.textViewGPA.setText("GPA: " + String.valueOf(calculateGPA()));


    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.test, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.item_add){
            mLisnter.goToAdd();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void deleteGrade(Grade grade) {
        mLisnter.deleteGrade(grade);

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mLisnter = (gradesListener) context;
    }

    gradesListener mLisnter;
    interface gradesListener {

        void goToAdd();
        void deleteGrade(Grade grade);
    }


    public double calculateGPA(){

        Double creditHours = 0.0;
        Double gradePionts = 0.0;

        if(mlist.size() == 0){
            //Log.d("TAG", "calculateGPA: ran here");
            return 4.0;
        }

    for(Grade g:mlist){
        creditHours += Double.valueOf(g.getCredits());

        if(g.getGrade().equals("A")) {


            gradePionts += Double.valueOf(g.getCredits()) * 4;
            Log.d("TAG", "calculateGPA: a" + gradePionts + " " + creditHours);
        } else if(g.getGrade().equals("B")) {


            gradePionts += Double.valueOf(g.getCredits()) * 3;
            Log.d("TAG", "calculateGPA: b" + gradePionts + " " + creditHours);
        } else if(g.getGrade().equals("C")) {
            //Log.d("TAG", "calculateGPA: c" + gradePionts + " " + creditHours);

            gradePionts += Double.valueOf(g.getCredits()) * 2;
        } else if(g.getGrade().equals("D")) {
            //Log.d("TAG", "calculateGPA: d" + gradePionts + " " + creditHours);

            gradePionts += Double.valueOf(g.getCredits()) * 1;
        } else {
            gradePionts += 0;
        }


    }
        binding.textView2.setText("Hours: " + String.valueOf(creditHours));

        return gradePionts/creditHours;
    }
}