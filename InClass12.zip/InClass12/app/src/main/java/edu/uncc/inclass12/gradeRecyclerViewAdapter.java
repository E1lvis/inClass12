package edu.uncc.inclass12;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class gradeRecyclerViewAdapter extends RecyclerView.Adapter<gradeRecyclerViewAdapter.gradeViewHolder> {

    List<Grade> mGrades;
    gradeRecyclerViewAdapter.adapterListener mListener;
    //gradeRecyclerViewAdapter.IC

    public gradeRecyclerViewAdapter(List<Grade> mGrades, adapterListener mListener){
        this.mGrades = mGrades;
        this.mListener = mListener;
    }



    @NonNull
    @Override
    public gradeRecyclerViewAdapter.gradeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grade_row_item, parent, false);
        gradeViewHolder gradeViewHolder = new gradeViewHolder(view, mListener);
        return gradeViewHolder;
    }



    @Override
    public void onBindViewHolder(@NonNull gradeRecyclerViewAdapter.gradeViewHolder holder, int position) {
        Grade grade = mGrades.get(position);
        holder.courseNumber.setText(grade.getCourseNumber());
        holder.grade.setText(grade.getGrade());
        holder.courseHours.setText(grade.getCredits());
        holder.courseName.setText(grade.getCourseName());



        holder.im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.deleteGrade(grade);
            }
        });

        holder.mGrade = grade;

    }



    @Override
    public int getItemCount() {
        return mGrades.size();
    }

    public static class gradeViewHolder extends RecyclerView.ViewHolder{

        Grade mGrade;
        TextView grade;
        TextView courseNumber;
        TextView courseName;
        TextView courseHours;
        ImageView im;
        gradeRecyclerViewAdapter.adapterListener mListener;

        public gradeViewHolder(@NonNull View itemView, gradeRecyclerViewAdapter.adapterListener mListener) {


            super(itemView);
            this.mListener = mListener;
            grade = itemView.findViewById(R.id.textViewCourseLetterGrade);
            courseHours = itemView.findViewById(R.id.textViewCourseHours);
            courseName = itemView.findViewById(R.id.textViewCourseName);
            courseNumber = itemView.findViewById(R.id.textViewCourseNumber);
            im = itemView.findViewById(R.id.imageViewDelete);
        }
    }



//not sure how to on attach for an adapter

    interface adapterListener {

        void deleteGrade(Grade grade);
    }

}
